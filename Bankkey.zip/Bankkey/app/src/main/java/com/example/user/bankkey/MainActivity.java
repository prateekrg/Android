package com.example.user.bankkey;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    EditText name,accno;
    Button BTN, BTN1;
    TextView keyview,acc_name,acc_num;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name=(EditText)findViewById(R.id.edit_name);
        accno=(EditText)findViewById(R.id.edit_acc);

        acc_name=(TextView)findViewById(R.id.textView_name);
        acc_num=(TextView)findViewById(R.id.textview_accno);

        keyview=(TextView)findViewById(R.id.key_view);

        BTN=(Button)findViewById(R.id.press);



        BTN.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {

                Random ran=new Random();
                int no=ran.nextInt(1000000000);
                keyview.setText(Long.toString(no));
                Toast.makeText(MainActivity.this,"Unique key is genearated",Toast.LENGTH_LONG).show();

            }
        });
    }
    public void Submit(View v)
    {
        String data=name.getText().toString();
        String data1=accno.getText().toString();
        acc_name.setText(data);
        acc_num.setText(data1);
        Toast.makeText(MainActivity.this,"Thank You using Bank Service",Toast.LENGTH_LONG).show();
    }

}
